fx_version 'cerulean'
game 'gta5'

author 'OnlineReloaded Team.'
description 'OnlineReloaded'
version 'pre-a0.0.1'

-- Load order matters: modules first, then the core that starts them.
server_scripts {
    'server/main.lua',
    'modules/player/player-data/server/server.lua',
    'modules/economy/server/server.lua',
}

client_scripts {
    'modules/economy/client/client.lua',
    'modules/player/inputmultiplayerinfohandler/client.lua',
}